import java.sql.*;
import java.util.*;



public class MyMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		/* All variables we will need to execute queries to the Database */
		String url = "jdbc:mysql://localhost:3306/covid"; // instead of covid you can swap for the name of your database
		Connection connection = null;
		Statement statement = null; // it contains the SQL query which will be sent to the Database
		ResultSet rs = null; // it contains "answers" for the above statement
		
		/* Credentials for MySQL Database */
		String uname = "root";
		String pass = "";
		
		/* Connection creation using the above credentials */
		Class.forName("com.mysql.jdbc.Driver");
		connection = DriverManager.getConnection(url,uname,pass); // making the connection to MySQL Database
		
		int menu = -1; // main menu selection pointer
		int sub_menu = -1; // submenu selection pointer
		Scanner in = new Scanner(System.in); // scanner type to read from console
		
		System.out.println("Covid Statistics - SGkats");
		/* Selection Menu */
		do {
			
			System.out.println("\n\nMain Menu \n");
			System.out.println("To create papers table in covid - press 1 \n");
			System.out.println("To insert data to papers from file - press 2 \n");
			System.out.println("To delete papers table in covid - press 3  \n");
			System.out.println("For statistics - press 4 \n");
			System.out.println("To exit - press 0 \n");
			
			/* standard input read for Main Menu */
			menu = in.nextInt();
			
			/* Table creation */
			switch (menu) {
				case 1:
				
					statement = connection.createStatement();
					boolean created = statement.execute("CREATE TABLE papers (sha VARCHAR(255) DEFAULT NULL, source_x VARCHAR(255) DEFAULT NULL, title VARCHAR(1000) DEFAULT NULL, doi VARCHAR(255) DEFAULT NULL, pmcid VARCHAR(255) DEFAULT NULL, pubmed_id INT DEFAULT NULL, license VARCHAR(255) DEFAULT NULL, abstract MEDIUMTEXT DEFAULT NULL, publish_time VARCHAR(255) DEFAULT NULL, authors TEXT, journal VARCHAR(255) DEFAULT NULL, MAPid BIGINT DEFAULT NULL, who VARCHAR(255) DEFAULT NULL, has_full_text VARCHAR(255) DEFAULT NULL);");
				
					statement.close(); // closing this statement and when we need a new one we will create it
				
					System.out.println("Creation successful \n");
					break;
				case 2:
				
					statement = connection.createStatement();
					rs = statement.executeQuery("LOAD DATA INFILE 'c:/ia_import.csv'\r\n" + 
						"INTO TABLE papers\r\n" + 
						"FIELDS TERMINATED BY ',' ENCLOSED BY '\"'\r\n" + 
						"LINES TERMINATED BY '\\n'\r\n" + 
						"IGNORE 1 ROWS\r\n");
				
					statement.close(); // closing this statement and when we need a new one we will create it
				
					System.out.println("Load successful \n");
					break;
				case 3:
				
					statement = connection.createStatement();
					boolean deleted = statement.execute("DROP TABLE papers;");
				
					statement.close(); // closing this statement and when we need a new one we will create it
				
					System.out.println("Deletion successful \n");
					break;
				
				case 4:
				
					do {
					
					/* Selection Submenu */
					System.out.println("\nSub Menu \n");
					System.out.println("To print which journal has the most papers out of 3 specific - press 1 \n");
					System.out.println("To print the percentage of papers between n specific journals - press 2\n");
					System.out.println("To print all titles of papers from specific journal - press 3 \n");
					System.out.println("To print the amount of entries in the table - press 4 \n");
					System.out.println("To exit Sub Menu - press 5 \n");
					
					/* standard input read for Submenu */
					sub_menu = in.nextInt();

					
					
					switch (sub_menu) {
					
						case 1: {
							
							int[] journal_count = new int[3];
							String[] journal_name = new String[3];
							
							for (int i=0;i<3;i++) {
								
								journal_count[i] = -1;
								journal_name[i] = "";
								
							}
							
							for (int i=0;i<3;i++) {
								System.out.println("Give exact name of journal: "+i+" \n");
								while (journal_name[i].isEmpty()) {
									journal_name[i] = in.nextLine(); // Reading from console
								}
							}
							
							for (int i=0;i<3;i++) {
								
								statement = connection.createStatement();
								rs = statement.executeQuery("SELECT COUNT(*) FROM papers WHERE STRCMP(papers.journal,\""+journal_name[i]+"\") = 0;");
								
								rs.next(); // To get to the first answer of the result set
								journal_count[i] = -1;
								journal_count[i] = rs.getInt(1); // Getting the first answer of the result set's table
								
								statement.close(); // closing this statement and when we need a new one we will create it
							}
							
							
							if((journal_count[0] > journal_count[1])&&(journal_count[0] > journal_count[2])) {
								
								System.out.println("Journal: "+journal_name[0]+" has the most papers, which are: " +journal_count[0]+" \n\n\n");
								
							}else if((journal_count[1] > journal_count[0])&&(journal_count[1] > journal_count[2])) {
								
								System.out.println("Journal: "+journal_name[1]+" has the most papers, which are: " +journal_count[1]+" \n\n\n");
								
							}else if((journal_count[2] > journal_count[0])&&(journal_count[1] > journal_count[1])) {
								
								System.out.println("Journal: "+journal_name[2]+" has the most papers, which are: " +journal_count[2]+" \n\n\n");
								
							}else {
								
								System.out.println("More than one journals have the most papers.\n\n\n");
								
							}
							
							break;
						}
						case 2: {
							
							System.out.println("Give the amount of journals\n");
							
							int amount = in.nextInt(); // Reading from console
							
							int[] journal_count = new int[amount];
							String[] journal_name = new String[amount];
							
							for (int i=0;i<amount;i++) {
								
								journal_count[i] = -1;
								journal_name[i] = "";
								
							}
							
							for (int i=0;i<amount;i++) {
								System.out.println("Give exact name of journal: "+(i+1)+" \n");
								while (journal_name[i].isEmpty()) {
									journal_name[i] = in.nextLine(); // Reading from console
								}
							}
							
							float sum = 0;
							for (int i=0;i<amount;i++) {
								
								statement = connection.createStatement();
								rs = statement.executeQuery("SELECT COUNT(*) FROM papers WHERE STRCMP(papers.journal,\""+journal_name[i]+"\") = 0;");
								
								rs.next(); // To get to the first answer of the result set
								journal_count[i] = -1;
								journal_count[i] = rs.getInt(1); // Getting the first answer of the result set's table
								sum = sum + journal_count[i];
								statement.close(); // closing this statement and when we need a new one we will create it
							}
							
							for (int i=0;i<amount;i++) {
								System.out.println("Journal: "+journal_name[i]+" has "+ (journal_count[i]/sum)*100 +"% of papers between all the selected journals \n");
							}
							
							break;
							
						}
						case 3: {
							
							System.out.println("Give exact name of journal \n");
							
							String search = "";
							while (search.isEmpty()) {
								search = in.nextLine(); // Reading from console
							}
							
							statement = connection.createStatement();
							rs = statement.executeQuery("SELECT title FROM papers WHERE STRCMP(papers.journal,\""+search+"\") = 0;");
							
							String temp_title = "";
							int i = 0;
							while (rs.next()) { // doing the condition check and moving the cursor to the next index
								i++; // 
								temp_title = rs.getString("title"); // getting the value of the column
								System.out.println(i+". "+temp_title+"\n");
							}
							
							statement.close();
							break;
						}
						case 4: {
							
							statement = connection.createStatement();
							rs = statement.executeQuery("SELECT COUNT(*) FROM papers;");
							
							rs.next();// To get to the first answer of the result set
							int total_count = rs.getInt(1);// Getting the first answer of the result set's table
							
							System.out.println("The total amount of papers in covid is: " +total_count+" \n\n\n");
							
							statement.close(); // closing this statement and when we need a new one we will create it
							break;
						}
					}
				}while (sub_menu != 5);
				
			}	 
		}while (menu != 0);
				
			connection.close(); // Closing the connection to the Database, when we finish our business with it
				
			System.out.println("\n\n\nProgram Ended. Bye! \n");
			
	}
					
}		


